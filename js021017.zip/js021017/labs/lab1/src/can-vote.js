//Your code goes here
let canVote = function() {}

let getVoters = function() {}

module.exports = {
  canVote: canVote,
  getVoters: getVoters
};
