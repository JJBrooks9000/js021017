"use strict";

const names = new Set();
names.add('Sara'); 
names.add('Paul');
names.add('Sara'); 

console.log(names);

const scores = new Map();
scores.set('Sara', 15);
scores.set('Paul', 12);

console.log(scores);