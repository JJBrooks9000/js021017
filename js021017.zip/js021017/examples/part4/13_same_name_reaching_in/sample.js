"use strict";

const sam = {
  first: 'Sam',
  age: 2
};

// const { age: age } = sam;
// console.log(age);

const { age } = sam;
console.log(age);