"use strict";

const sam = {
  first: 'Sam',
  age: 2
};

const { age: theAge } = sam;
console.log(theAge);