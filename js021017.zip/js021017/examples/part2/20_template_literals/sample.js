"use strict";

const name = 'Joe';            
              
const msg = 'hi';

const toPrint = msg + ' ' + name + ", how're you?";

console.log(toPrint);

const toPrint2 = `${msg} ${name}, how're you?`;

console.log(toPrint2);