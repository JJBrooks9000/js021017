"use strict";

const power = function(n, e = 2) {
  return Math.pow(n, e);
}

console.log(power(4, 2));
console.log(power(4, 3));

console.log(power(4));