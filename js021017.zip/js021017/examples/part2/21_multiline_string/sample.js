"use strict";

const name = 'Joe';            

const today = new Date();

const memo = `This memo was created on this wonderful day
${today} at the location of...
where in attenance was ${name}....
`

console.log(memo);