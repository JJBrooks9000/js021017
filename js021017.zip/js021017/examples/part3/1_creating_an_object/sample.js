"use strict";

const sam = {
  first: 'Sam',
  age: 2,
  play: function() { console.log('playing...'); }
};

console.log(sam);
sam.play();