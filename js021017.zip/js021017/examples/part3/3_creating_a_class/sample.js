"use strict";

class Car {} //in all honesty, JavaScript has no classes. It only has
//function and constructor function. You actually create objects from
//their constructor functions. We loosely call the constructor function
//as class in JavaScript.

console.log(Car);