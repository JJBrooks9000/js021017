"use strict";

var a = 1;

console.log(a);

var a = "hello";
console.log(a);

let b = 1;
console.log(b);                  
b = 2; //ok

let b = 'hello'; //can't redefine
console.log(b);