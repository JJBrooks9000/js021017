"use strict";

let v1 = 4;
console.log(v1);

v1 = 7;
console.log(v1);

const v2 = 4;
console.log(v2);
//v2 = 7; //ERROR
console.log(v2);