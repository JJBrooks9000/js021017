var foo = function(n) {
  if(n > 5)
    return n; 
  else {
    return
      n * 2;
  }
}            

console.log(foo(6));
console.log(foo(3));